<?php

namespace Drupal\devel_generate;

/**
 * DevelGenerateException extending Generic Plugin exception class.
 */
class DevelGenerateException extends \Exception {

}
